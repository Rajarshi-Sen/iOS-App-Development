//: Playground - noun: a place where people can play
/**********************************************************************************************************************************************
 * Name             : Rajarshi Sen
 * Z-ID             : z1816768
 * Course Number    : CSCI-521
 * Assignment Number: 2 - Part-I
 * Purpose          : Write Swift 4 code to find primes for a given integer greater than or equal to 25 using the provided algorithm
 * Due Date         : February 15, 2018 by 11:59 pm
 **********************************************************************************************************************************************/

/****** Algortithm_Provided ******************************************************************
 * create an array of maxInt booleans and initialize each to true.
 • for each number 2 to sqrt(maxInt), "cross out" all the multiples of that number (i.e.
   set them to false - they are not prime) in the array. So array[4] = false, array[6] =
   false... and then array[6] = false, array[9] = false...
 • when you are done, those array elements that are still true are primes (do not
   report 0 or 1 as prime).
 *********************************************************************************************/

import UIKit

let userInput = 29
if userInput < 25 {
    exit(-1)
}

var maxInt = [Bool](repeating: true, count: userInput+1) // to accomodate till maxInt[29]

var i = 2
while i <= Int(sqrt(Double(userInput))){
    var j = 2
    while i * j <= userInput{
        maxInt[i*j] = false
        j += 1
    }
    i += 1
}

i = 2
repeat{
    if maxInt[i]{
        print(i)
    }
    i += 1
}while i <= userInput
